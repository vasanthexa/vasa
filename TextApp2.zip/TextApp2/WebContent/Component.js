sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel", "sap/ui/model/odata/ODataModel" ],
	function(UIComponent, JSONModel,ResourceModel,ODataModel) {

	return UIComponent.extend("TextApp2.Component",{
		
		metadata:{
			manifest:"json"
		},
				
		init:function(){
			var sServiceUrl = this.getMetadata().getManifestEntry("sap.app").dataSources.positionService.uri;
            var oModel = new ODataModel(sServiceUrl, {
                json: true,
                defaultCountMode: "None",
            });
            this.setModel(oModel);            
			UIComponent.prototype.init.apply(this,arguments);
			this.getRouter().initialize();
		}
		
	});
});



