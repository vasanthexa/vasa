sap.ui.define(["TextApp2/controller/BaseController","sap/ui/core/mvc/Controller"],
		function(BaseController,Controller) {
	    "use strict";
	    return BaseController.extend("TextApp2.controller.InitialData", {
	    	
	    	onInit:function(){
	            this.buildTable();
	            this.buildPie();
	    	},
	    	
	    	onAfterRendering:function(){
	    		var launCheck1 = sap.ui.getCore().getConfiguration().getLanguage();
	    		var launCheck2 = navigator.language;
	    		if(launCheck1 == "iw" || launCheck2 == "he"){
	    			var i18n = new sap.ui.model.resource.ResourceModel({
	    				bundleUrl: "../TextApp2/i18n/i18n_iw.properties",
	    				bundleLocal: sap.ui.getCore().getConfiguration().getLanguageTag()
	    			});
	    			sap.ui.getCore().getConfiguration().setRTL(true);
	    		}else{
	    			var i18n = new sap.ui.model.resource.ResourceModel({
	    				bundleUrl: "../TextApp2/i18n/i18n.properties",
	    				bundleLocal: sap.ui.getCore().getConfiguration().getLanguageTag()
	    			});
	    			sap.ui.getCore().getConfiguration().setRTL(false);
	    		}
	    		sap.ui.getCore().setModel(i18n, "i18n");
	    		var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
	    		var docTit = i18nModel.getText('TEXT_DIR');
	    		document.title = docTit;
	    	},
	    	
	    	buildTable:function(){
	    		var that = this;
	    		var url = "/Customers";
	            var oModel = this.getOwnerComponent().getModel();	           
	            var busyDlg = new sap.m.BusyDialog({
	            	text:"Loading..."
	            });
	            busyDlg.open();
	            oModel.read(url, null, null, false, function(oData, oResponse) {	       
	            	that.bindInitData(oData.results);	            	
	            	busyDlg.close();
	            }, function(value) {
	            	busyDlg.close();
	            });
	    	},
	    	
	    	buildPie:function(){
	    		//get i18n Model
	    	    var i18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
//	          Get the id of the VizFrame		
	    		var oVizFrame = this.getView().byId("idpiechart");	    		
//	          Create a JSON Model and set the data
	    		var oModel = new sap.ui.model.json.JSONModel();
	    		var data = {
	    			'Sales' : [{
	    				  "DrugName": i18nModel.getText('CRAN_CRM'),
	    				  "Revenue": "7.37"
	    				}, {
	    				  "DrugName": i18nModel.getText('WART_REM_LIQ'),
	    				  "Revenue": "9.54"
	    				}, {
	    				  "DrugName": i18nModel.getText('HYDEROCHL'),
	    				  "Revenue": "6.57"
	    				}, {
	    				  "DrugName": i18nModel.getText('TERAZOS'),
	    				  "Revenue": "5.41"
	    				}, {
	    				  "DrugName": i18nModel.getText('TOPIR'),
	    				  "Revenue": "8.69"
	    				}]};
	    		oModel.setData(data);	    		
//	            Create Viz dataset to feed to the data to the graph
	    		var oDataset = new sap.viz.ui5.data.FlattenedDataset({
	    			dimensions : [{
	    			    name : 'Drug Name',
	    				value : "{DrugName}"}],
	    			               
	    			measures : [{
	    				name : 'Revenue',
	    				value : '{Revenue}'} ],
	    			             
	    			data : {
	    				path : "/Sales"
	    			}
	    		});		
	    		oVizFrame.setDataset(oDataset);
	    		oVizFrame.setModel(oModel);		    		
//	            Set Viz properties
	    		oVizFrame.setVizProperties({
	    			title:{
	    				text : i18nModel.getText('REVENUE')
	    			},
	                plotArea: {
	                	colorPalette : d3.scale.category20().range(),
	                	drawingEffect: "glossy"
	                    }});
	    		
	    		var feedSize = new sap.viz.ui5.controls.common.feeds.FeedItem({
	    		      'uid': "size",
	    		      'type': "Measure",
	    		      'values': ["Revenue"]
	    		    }), 
	    		    feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
	    		      'uid': "color",
	    		      'type': "Dimension",
	    		      'values': ["Drug Name"]
	    		    });
	    		oVizFrame.addFeed(feedSize);
	    		oVizFrame.addFeed(feedColor);
	    	},
	    	
	    	bindInitData:function(oData){
	        	var tblTemplate = new sap.m.ColumnListItem({
	    			cells:[
	    			       new sap.m.Text({
	    			    	  text : "{overViewModel>CustomerID}"
	    			       }),
	    			       new sap.m.Text({
	    			    	  text : "{overViewModel>CompanyName}" 
	    			       }),
	    			       new sap.m.Text({			    	  
	    			    	  text:"{overViewModel>ContactName}"
	    			       }),
	    			       new sap.m.Text({			    	  
	    			    	  text:"{overViewModel>ContactTitle}"
	    			       }),
	    			       new sap.m.Text({	
	    			    	   text:"{overViewModel>Address}"
	    			       }),
	    			       new sap.m.Text({		
	    			    	   text:"{overViewModel>City}"
	    			       }),
	    			       new sap.m.Text({
	    			    	  text: "{overViewModel>PostalCode}"
	    			       })
	    			  ]
	    		});
	    		var oTable = this.getView().byId("idIniTable");
	    		var oTableModel = new sap.ui.model.json.JSONModel(oData);
	    		oTable.setModel(oTableModel,"overViewModel");
	    		oTable.bindAggregation("items",{
	    			path:"overViewModel>/",
	    			template:tblTemplate,
	    		});
	        },
	    	
	    });
});