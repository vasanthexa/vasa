sap.ui.controller("TextApp2.controller.Main", {
	onInit: function() {
		if (sap.ui.Device.support.touch === false) {
		
			this.getView().addStyleClass("sapUiSizeCompact");
		}
	}
});